<footer class="footer text-center text-muted">
&copy; <?php echo date("Y"); ?> - MIT WPU Hostel - Developed by <a href="https://mitwpu.edu.in/">MIT WPU</a>
</footer>